export class Course {
    public Name : string
    public Dates : any[]
    public Groups : string[]
    public Id : string
}