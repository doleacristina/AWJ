export class User {
    public Name : string
    public Surname : string
    public Email : string
    public ID : string
    public Username : string
    public Password : string
    public Attendance : string[]
}
